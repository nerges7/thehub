// Deporte
export interface Sport {
  id: string;
  name: string;
  description?: string;
}

// Categoría de producto
export interface Category {
  id: string;
  name: string;
  description?: string;
  sportIds: string[]; // IDs de los deportes relacionados
}

// Producto
export interface Product {
  id: string;
  shopifyGid: string;
  name: string;
  description?: string;
  categoryIds: string[];
  priority: number;
  amountPerUnit: number; 
}

// Pregunta asociada a un deporte
export interface Question {
  id: string;
  sportId?: string; // ← ahora opcional
  text: string;
  key: string;
  type: 'select' | 'number' | 'text'| 'time'; // ← incluiste 'text' en el form
  order: number;
  options?: string[];
  unit?: string;
  forAllSports?: boolean; // ← nuevo campo para marcar pregunta general
}





// Futuro: Regla de cálculo (relacionada a categoría y preguntas)
export interface Condition {
  questionId: string;
  operator: '=' | '>' | '<' | '>=' | '<=' | 'includes';
  value: string | number;
}

export interface Rule {
  id: string;
  categoryId: string;
  baseQuestionKey: string;
  baseMultiplier: number;
  baseQuestionType: 'number' | 'time';
  logic: 'AND' | 'OR';
  modifiers: {
    key: string;
    value: string;
    multiplier: number;
  }[];
}

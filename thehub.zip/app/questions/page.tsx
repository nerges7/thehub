'use client';

import {
  Page,
  Card,
  ResourceList,
  Button,
  Select,
  Modal,
  Text,
} from '@shopify/polaris';
import { PlusIcon } from '@shopify/polaris-icons';
import { useEffect, useState } from 'react';
import { getSports } from '../sports/utils';
import { getQuestions, deleteQuestion, updateQuestion } from './utils';
import { Question, Sport } from '@/types';
import QuestionForm from './QuestionForm';
import { stripHtml } from '@/utils/stripHtml';
// dnd-kit
import {
  DndContext,
  PointerSensor,
  useSensor,
  useSensors,
  closestCenter,
} from '@dnd-kit/core';
import {
  SortableContext,
  useSortable,
  arrayMove,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

export default function QuestionsPage() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [sports, setSports] = useState<Sport[]>([]);
  const [sportFilter, setSportFilter] = useState<string>('all');
  const [openModal, setOpenModal] = useState(false);
  const [selected, setSelected] = useState<Question | null>(null);

  const loadData = async () => {
    const [qs, ss] = await Promise.all([getQuestions(), getSports()]);
    setQuestions(qs);
    setSports(ss);
  };

  useEffect(() => {
    loadData();
  }, []);

const filteredQuestions =
  sportFilter === 'all'
    ? questions
    : questions.filter((q) => q.sportId === sportFilter && !q.forAllSports);

  const sortedQuestions = [...filteredQuestions].sort((a, b) => a.order - b.order);

  const sportOptions = [
    { label: 'Todos los deportes', value: 'all' },
    ...sports.map((s) => ({ label: s.name, value: s.id })),
  ];

  const handleReorder = async (newOrder: Question[]) => {
    if (sportFilter === 'all') return;

    const updatedQuestions = [...questions];
    newOrder.forEach((q, i) => {
      const index = updatedQuestions.findIndex((item) => item.id === q.id);
      if (index !== -1) {
        updatedQuestions[index] = { ...q, order: i };
      }
    });

    setQuestions(updatedQuestions);

    for (let i = 0; i < newOrder.length; i++) {
      const q = newOrder[i];
      const { id, ...rest } = q;
      const updated = { ...rest, order: i };
      await updateQuestion(id, updated);
    }
  };

const getSportName = (id?: string, forAllSports?: boolean) => {
  if (forAllSports) return 'Todos';
  return sports.find((s) => s.id === id)?.name || '—';
};

  const sensors = useSensors(useSensor(PointerSensor));

  const SortableItem = ({
    question,
    onClick,
    onDelete,
  }: {
    question: Question;
    onClick: () => void;
    onDelete: () => void;
  }) => {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
      id: question.id,
    });

    const style = {
      transform: CSS.Transform.toString(transform),
      transition,
    };

    return (
      <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
        <ResourceList.Item id={question.id} onClick={onClick}>
          <div>
            <Text variant="bodyMd" fontWeight="bold" as="h3">
              {question.text}
            </Text>
         <Text variant="bodySm" tone="subdued" as="p">
  Tipo: {question.type === 'number' ? 'Numérica' : 'Selección'}
  {question.unit ? ` (${question.unit})` : ''} | Deporte: {getSportName(question.sportId, question.forAllSports)}
</Text>
            <div className="mt-2">
              <Button size="slim" onClick={onDelete} tone='critical'>
                Eliminar
              </Button>
            </div>
          </div>
        </ResourceList.Item>
      </div>
    );
  };

  return (
    <Page
      title="Preguntas"
      primaryAction={{
        content: 'Agregar pregunta',
        icon: PlusIcon,
        onAction: () => {
          setSelected(null);
          setOpenModal(true);
        },
      }}
    >
      <Card>
        <div className="p-4">
          <Select
            label="Filtrar por deporte"
            options={sportOptions}
            value={sportFilter}
            onChange={setSportFilter}
          />
        </div>

        {sportFilter === 'all' ? (
          <ResourceList
            resourceName={{ singular: 'pregunta', plural: 'preguntas' }}
            items={sortedQuestions}
            renderItem={(q) => (
              <ResourceList.Item
                id={q.id}
                onClick={() => {
                  setSelected(q);
                  setOpenModal(true);
                }}
              >
                <div>
                  <Text variant="bodyMd" fontWeight="bold" as="h3">{stripHtml(q.text)}</Text>
                  <Text variant="bodySm" tone="subdued" as="p">
                    Tipo: {q.type === 'number' ? 'Numérica' : 'Selección'}
                    {q.unit ? ` (${q.unit})` : ''} | Deporte: {getSportName(q.sportId)}
                  </Text>
                  <div className="mt-2">
                    <Button
                      size="slim"
                      tone='critical'
                       onClick={() => {
    deleteQuestion(q.id).then(loadData);
  }}
                    >
                      Eliminar
                    </Button>
                  </div>
                </div>
              </ResourceList.Item>
            )}
          />
        ) : (
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={({ active, over }) => {
              if (!over || active.id === over.id) return;
              const oldIndex = sortedQuestions.findIndex((q) => q.id === active.id);
              const newIndex = sortedQuestions.findIndex((q) => q.id === over.id);
              const newList = arrayMove(sortedQuestions, oldIndex, newIndex);
              handleReorder(newList);
            }}
          >
            <SortableContext
              items={sortedQuestions.map((q) => q.id)}
              strategy={verticalListSortingStrategy}
            >
              {sortedQuestions.map((q) => (
                <SortableItem
                  key={q.id}
                  question={q}
                  onClick={() => {
                    setSelected(q);
                    setOpenModal(true);
                  }}
                  onDelete={() => {
                    deleteQuestion(q.id).then(loadData);
                  }}
                />
              ))}
            </SortableContext>
          </DndContext>
        )}
      </Card>

      <Modal
        open={openModal}
        onClose={() => setOpenModal(false)}
        title={selected ? 'Editar pregunta' : 'Nueva pregunta'}
 
      >
        <Modal.Section>
          <QuestionForm
            defaultValues={selected || undefined}
            onSuccess={() => {
              setOpenModal(false);
              loadData();
            }}
            onClose={() => setOpenModal(false)}
          />
        </Modal.Section>
      </Modal>
    </Page>
  );
}

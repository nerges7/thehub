'use client';

import { useEffect, useState } from 'react';
import { TextField, Select, Button, Checkbox, Icon } from '@shopify/polaris';
import {PlusCircleIcon, MinusCircleIcon} from '@shopify/polaris-icons';
import { getSports } from '../sports/utils';
import { addQuestion, updateQuestion, getQuestions } from './utils';
import { Sport, Question } from '@/types';
import { generateKeyFromText } from '@/utils/slugify';
import RichText from '@/components/RichText'
import { stripHtml } from '@/utils/stripHtml';
interface Props {
  defaultValues?: Question;
  onSuccess: () => void;
  onClose: () => void;
}

export default function QuestionForm({ defaultValues, onSuccess, onClose }: Props) {
  const [sports, setSports] = useState<Sport[]>([]);
  const [text, setText] = useState(defaultValues?.text || '');
  const [key, setKey] = useState(defaultValues?.key || '');
  const [type, setType] = useState<'text' | 'number' | 'select' | 'time'>(defaultValues?.type || 'text');
  const [sportId, setSportId] = useState(defaultValues?.sportId || '');
  const [optionsList, setOptionsList] = useState<string[]>(defaultValues?.options || []);
  const [unit, setUnit] = useState(defaultValues?.unit || '');
  const [forAllSports, setForAllSports] = useState(defaultValues?.forAllSports || false);

  useEffect(() => {
    getSports().then(setSports);
  }, []);

  useEffect(() => {
    if (!defaultValues) {
      setKey(generateKeyFromText(stripHtml(text)));
    }
  }, [text]);

  const handleSubmit = async () => {
    const payload: any = {
      text,
      key,
      type,
      forAllSports,
      ...(type === 'select' && {
        options: optionsList.map((opt) => opt.trim()).filter(Boolean),
      }),
      ...(type === 'number' ? { unit } : {}),
    };

    if (!forAllSports) {
      payload.sportId = sportId;
    }

    if (!payload.options || payload.options.length === 0) {
      delete payload.options;
    }

    if (defaultValues?.id) {
      await updateQuestion(defaultValues.id, payload);
    } else {
      const existing = await getQuestions();
      const sportQuestions = existing.filter((q) => forAllSports || q.sportId === sportId);
      const maxOrder = sportQuestions.length
        ? Math.max(...sportQuestions.map((q) => q.order ?? 0))
        : -1;

      await addQuestion({
        ...payload,
        order: maxOrder + 1,
      });
    }

    onSuccess();
  };

  const updateOption = (index: number, value: string) => {
    const updated = [...optionsList];
    updated[index] = value;
    setOptionsList(updated);
  };

  const addOption = () => {
    setOptionsList([...optionsList, '']);
  };

  const removeOption = (index: number) => {
    setOptionsList(optionsList.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
       <RichText
  value={text}
  onChange={setText}
/>

      <TextField
        label="Clave interna (key)"
        helpText="Se genera automáticamente desde el texto. Puedes modificarla si lo deseas."
        value={key}
        onChange={setKey}
        autoComplete="off"
      />

      <Select
        label="Tipo de pregunta"
        options={[
          { label: 'Texto', value: 'text' },
          { label: 'Número', value: 'number' },
          { label: 'Selección', value: 'select' },
          { label: 'Tiempo (horas y minutos)', value: 'time' },
        ]}
        value={type}
        onChange={(val) => setType(val as 'text' | 'number' | 'select' | 'time')}
      />

      {type === 'number' && (
        <TextField
          label="Unidad (ej. km, mi, mt)"
          value={unit}
          onChange={setUnit}
          autoComplete="off"
        />
      )}

      {type === 'select' && (
        <div className="space-y-2">
          <label className="font-medium text-sm text-gray-700">Opciones</label>
          {optionsList.map((opt, index) => (
            <div key={index} className="flex gap-2 items-center" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <TextField
                labelHidden
                label={`Opción ${index + 1}`}
                value={opt}
                onChange={(val) => updateOption(index, val)}
                autoComplete="off"
              />
              <Button
                icon={MinusCircleIcon}
                onClick={() => removeOption(index)}
                tone="critical"
              />
            </div>
          ))}
          <Button icon={PlusCircleIcon} onClick={addOption}>
            Agregar opción
          </Button>
        </div>
      )}

      <Checkbox
        label="Pregunta general (para todos los deportes)"
        checked={forAllSports}
        onChange={setForAllSports}
      />

      <Select
        label="Deporte"
        options={sports.map((s) => ({ label: s.name, value: s.id }))}
        value={sportId}
        onChange={setSportId}
        disabled={forAllSports}
      />

      <div className="flex justify-end">
        <Button onClick={handleSubmit}>
          {defaultValues ? 'Actualizar' : 'Crear'}
        </Button>
      </div>
    </div>
  );
}
